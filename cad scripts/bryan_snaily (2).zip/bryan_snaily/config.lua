Config = {}

Config.Defaults = {
    registrationStatus = 'Valid'
}

Config.API = {
    URL = 'https://api-test.swiftpeakhosting.co.uk/v1/',
    TOKEN = 'sng_4TiV5Zuszyn9iDRQhnOpCXvrqPbvP9-VTF4SEl2uB5zYqXm1OkHIlD3R',
    TOKEN_HEADER_NAME = 'snaily-cad-api-token',
}