fx_version 'cerulean'
game 'gta5'

author 'BryaN'

shared_script 'config.lua'
server_scripts {
    'server/*.lua'
}